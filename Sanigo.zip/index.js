const { Client, GatewayIntentBits, Partials, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const express = require('express');
const session = require('express-session');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcrypt');
const { config, saveConfig } = require('./settings');

const ticketsDB = {
    tickets: []
};

if (fs.existsSync('./tickets.json')) {
    Object.assign(ticketsDB, JSON.parse(fs.readFileSync('./tickets.json', 'utf8')));
}

function saveTickets() {
    fs.writeFileSync('./tickets.json', JSON.stringify(ticketsDB, null, 4));
}

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.DirectMessages
    ],
    partials: [Partials.Channel, Partials.Message]
});

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
    secret: 'ticket-panel-secret',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }
}));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.get('/', (req, res) => {
    res.redirect('/login');
});

function isAuthenticated(req, res, next) {
    if (req.session.authenticated) {
        return next();
    }
    res.redirect('/login');
}

app.get('/login', (req, res) => {
    res.render('login');
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;
    
    if (username === config.admin.username && password === config.admin.password) {
        req.session.authenticated = true;
        req.session.username = username;
        res.redirect('/dashboard');
    } else {
        res.render('login', { error: 'خطأ في اسم المستخدم أو كلمة المرور' });
    }
});

app.get('/dashboard', isAuthenticated, (req, res) => {
    res.render('dashboard', { config, tickets: ticketsDB.tickets });
});

app.post('/save-config', isAuthenticated, (req, res) => {
    const { ticketPanel, ticketLogs, responseChannel, username, password, port, guildId, clientId, token } = req.body;
    
    config.channels.ticketPanel = ticketPanel;
    config.channels.ticketLogs = ticketLogs;
    config.channels.responseChannel = responseChannel;
    
    if (username && username !== config.admin.username) {
        config.admin.username = username;
    }
    
    if (password && password !== config.admin.password) {
        config.admin.password = password;
    }
    
    if (port) config.port = port;
    if (guildId) config.guildId = guildId;
    if (clientId) config.clientId = clientId;
    if (token) config.token = token;
    
    saveConfig();
    res.redirect('/dashboard');
});

app.post('/send-panel', isAuthenticated, async (req, res) => {
    try {
        const channel = await client.channels.fetch(config.channels.ticketPanel);
        if (!channel) {
            return res.render('dashboard', { config, tickets: ticketsDB.tickets, error: 'القناة غير موجودة' });
        }
        
        const embed = new EmbedBuilder()
            .setTitle(config.panelTitle)
            .setDescription(config.panelDescription)
            .setColor(config.panelColor)
            .setTimestamp();
        
        if (config.panelImage && config.panelImage.trim() !== '') {
            embed.setImage(config.panelImage);
        }
        
        const rows = [];
        let currentRow = new ActionRowBuilder();
        let buttonCount = 0;
        
        for (let i = 0; i < config.buttons.length; i++) {
            const button = config.buttons[i];
            
            let buttonStyle;
            switch(button.style.toUpperCase()) {
                case 'PRIMARY':
                    buttonStyle = ButtonStyle.Primary;
                    break;
                case 'SECONDARY':
                    buttonStyle = ButtonStyle.Secondary;
                    break;
                case 'SUCCESS':
                    buttonStyle = ButtonStyle.Success;
                    break;
                case 'DANGER':
                    buttonStyle = ButtonStyle.Danger;
                    break;
                default:
                    buttonStyle = ButtonStyle.Primary;
            }
            
            const newButton = new ButtonBuilder()
                .setCustomId(button.id)
                .setLabel(button.label)
                .setStyle(buttonStyle)
                
            if (button.emoji) {
                newButton.setEmoji(button.emoji);
            }
            
            currentRow.addComponents(newButton);
            buttonCount++;
            
            if (buttonCount === 5 || i === config.buttons.length - 1) {
                rows.push(currentRow);
                currentRow = new ActionRowBuilder();
                buttonCount = 0;
            }
        }
        
        await channel.send({ embeds: [embed], components: rows });
        res.redirect('/dashboard');
    } catch (error) {
        console.error('خطأ في إرسال البانل:', error);
        res.render('dashboard', { config, tickets: ticketsDB.tickets, error: 'خطأ في إرسال البانل' });
    }
});

app.post('/add-button', isAuthenticated, (req, res) => {
    const { id, label, style, emoji } = req.body;
    let questions = req.body.questions || ["ما هي تفاصيل طلبك؟"];
    
    if (config.buttons.some(btn => btn.id === id)) {
        return res.render('dashboard', { config, tickets: ticketsDB.tickets, error: 'يوجد زر بنفس المعرف بالفعل' });
    }
    
    if (questions.length > 5) {
        questions = questions.slice(0, 5);
    }
    
    config.buttons.push({
        id,
        label,
        style: style.toUpperCase() || 'PRIMARY',
        emoji: emoji || '',
        questions: questions
    });
    
    saveConfig();
    res.redirect('/dashboard#buttons');
});

app.post('/update-button/:index', isAuthenticated, (req, res) => {
    const index = parseInt(req.params.index);
    const { id, label, style, emoji } = req.body;
    let questions = req.body.questions || ["ما هي تفاصيل طلبك؟"];
    
    if (isNaN(index) || index < 0 || index >= config.buttons.length) {
        return res.render('dashboard', { config, tickets: ticketsDB.tickets, error: 'الزر غير موجود' });
    }
    
    if (questions.length > 5) {
        questions = questions.slice(0, 5);
    }
    
    config.buttons[index] = {
        id,
        label,
        style: style.toUpperCase() || 'PRIMARY',
        emoji: emoji || '',
        questions: questions
    };
    
    saveConfig();
    res.redirect('/dashboard#buttons');
});

app.post('/delete-button/:index', isAuthenticated, (req, res) => {
    const index = parseInt(req.params.index);
    
    if (isNaN(index) || index < 0 || index >= config.buttons.length) {
        return res.render('dashboard', { config, tickets: ticketsDB.tickets, error: 'الزر غير موجود' });
    }
    
    config.buttons.splice(index, 1);
    
    saveConfig();
    res.redirect('/dashboard#buttons');
});

app.post('/update-panel-settings', isAuthenticated, (req, res) => {
    const { panelTitle, panelDescription, panelColor, panelImage } = req.body;
    
    config.panelTitle = panelTitle || config.panelTitle;
    config.panelDescription = panelDescription || config.panelDescription;
    config.panelColor = panelColor || config.panelColor;
    config.panelImage = panelImage || '';
    
    saveConfig();
    res.redirect('/dashboard#buttons');
});

app.post('/approve-ticket/:id', isAuthenticated, async (req, res) => {
    const { id } = req.params;
    const ticket = ticketsDB.tickets.find(t => t.id === id);
    
    if (!ticket) {
        return res.redirect('/dashboard');
    }
    
    ticket.status = 'approved';
    ticket.approvedBy = req.session.username || 'مسؤول';
    saveTickets();
    
    try {
        const logsChannel = await client.channels.fetch(config.channels.ticketLogs);
        const logsEmbed = new EmbedBuilder()
            .setTitle('✅ تم قبول الطلب')
            .setDescription(`تم قبول طلب <@${ticket.userId}>`)
            .addFields(
                { name: '🏷️ نوع الطلب', value: ticket.type },
                { name: '📝 التفاصيل', value: ticket.details },
                { name: '👤 تمت الموافقة بواسطة', value: ticket.approvedBy }
            )
            .setColor('#28a745')
            .setTimestamp()
            .setFooter({ text: 'نظام الطلبات | تمت الموافقة' });
        
        await logsChannel.send({ embeds: [logsEmbed] });
        
        const responseChannel = await client.channels.fetch(config.channels.responseChannel);
        const user = await client.users.fetch(ticket.userId);
        
        const responseEmbed = new EmbedBuilder()
            .setTitle('✅ تم قبول الطلب')
            .setDescription(`مرحباً ${user.username}، تم قبول طلبك بنجاح!`)
            .addFields(
                { name: '🏷️ نوع الطلب', value: ticket.type, inline: true },
                { name: '📅 تاريخ الطلب', value: new Date(ticket.createdAt).toLocaleDateString('ar-SA'), inline: true },
                { name: '📝 التفاصيل', value: ticket.details }
            )
            .setColor('#28a745')
            .setThumbnail(user.displayAvatarURL({ dynamic: true }))
            .setTimestamp()
            .setFooter({ text: 'شكراً لتقديم طلبك! | نظام الطلبات' });
        
        await responseChannel.send({ content: `<@${ticket.userId}>`, embeds: [responseEmbed] });
        
        await user.send({ embeds: [responseEmbed] });
    } catch (error) {
        console.error('خطأ في الموافقة على الطلب:', error);
    }
    
    res.redirect('/dashboard');
});

app.post('/reject-ticket/:id', isAuthenticated, async (req, res) => {
    const { id } = req.params;
    const { reason } = req.body;
    const ticket = ticketsDB.tickets.find(t => t.id === id);
    
    if (!ticket) {
        return res.redirect('/dashboard');
    }
    
    ticket.status = 'rejected';
    ticket.reason = reason;
    ticket.rejectedBy = req.session.username || 'مسؤول';
    saveTickets();
    
    try {
        const logsChannel = await client.channels.fetch(config.channels.ticketLogs);
        const logsEmbed = new EmbedBuilder()
            .setTitle('❌ تم رفض الطلب')
            .setDescription(`تم رفض طلب <@${ticket.userId}>`)
            .addFields(
                { name: '🏷️ نوع الطلب', value: ticket.type },
                { name: '📝 التفاصيل', value: ticket.details },
                { name: '❓ سبب الرفض', value: reason || 'لم يتم ذكر سبب' },
                { name: '👤 تم الرفض بواسطة', value: ticket.rejectedBy }
            )
            .setColor('#dc3545')
            .setTimestamp()
            .setFooter({ text: 'نظام الطلبات | تم الرفض' });
        
        await logsChannel.send({ embeds: [logsEmbed] });
        
        const responseChannel = await client.channels.fetch(config.channels.responseChannel);
        const user = await client.users.fetch(ticket.userId);
        
        const responseEmbed = new EmbedBuilder()
            .setTitle('❌ تم رفض الطلب')
            .setDescription(`مرحباً ${user.username}، نأسف لإبلاغك بأنه تم رفض طلبك.`)
            .addFields(
                { name: '🏷️ نوع الطلب', value: ticket.type, inline: true },
                { name: '📅 تاريخ الطلب', value: new Date(ticket.createdAt).toLocaleDateString('ar-SA'), inline: true },
                { name: '📝 التفاصيل', value: ticket.details },
                { name: '❓ سبب الرفض', value: reason || 'لم يتم ذكر سبب' }
            )
            .setColor('#dc3545')
            .setThumbnail(user.displayAvatarURL({ dynamic: true }))
            .setTimestamp()
            .setFooter({ text: 'يمكنك تقديم طلب آخر في أي وقت | نظام الطلبات' });
        
        await responseChannel.send({ content: `<@${ticket.userId}>`, embeds: [responseEmbed] });
        
        await user.send({ embeds: [responseEmbed] });
    } catch (error) {
        console.error('خطأ في رفض الطلب:', error);
    }
    
    res.redirect('/dashboard');
});

app.get('/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/login');
});

client.once('ready', () => {
    console.clear();
    const line = '─'.repeat(50);
    console.log(line);
    console.log(`🌐 ${client.user.tag} is now online!`);
    console.log(line);
    console.log(`🤖 Bot Username  : ${client.user.username}`);
    console.log(`🆔 Bot ID        : ${client.user.id}`);
    console.log(`📅 Launched On   : ${new Date().toLocaleString()}`);
    console.log(line);
    console.log(`📊 Connected to  : ${client.guilds.cache.size} servers`);
    console.log(`👥 Total Users   : ${client.users.cache.size}`);
    console.log(`📁 Events System : Initialized`);
    console.log(line);
    console.log(`© 2024 wickstudio - All Rights Reserved.`);
    console.log(`🔗 GitHub: https://github.com/wickstudio`);
    console.log(`🌐 YouTube: https://www.youtube.com/@wick_studio`);
    console.log(`💬 Discord: https://discord.gg/wicks`);
    console.log(line);
    console.log('✅ Bot is fully operational and ready to serve!');
    console.log(line);
});

client.on('interactionCreate', async interaction => {
    if (interaction.isButton()) {
        const buttonConfig = config.buttons.find(btn => btn.id === interaction.customId);
        
        if (buttonConfig) {
            const modal = new ModalBuilder()
                .setCustomId(`modal_${buttonConfig.id}`)
                .setTitle(buttonConfig.label);
            
            if (buttonConfig.questions && buttonConfig.questions.length > 0) {
                buttonConfig.questions.forEach((question, index) => {
                    const inputId = `question_${index}`;
                    const questionInput = new TextInputBuilder()
                        .setCustomId(inputId)
                        .setLabel(question)
                        .setPlaceholder(`اكتب إجابتك هنا...`)
                        .setStyle(index === buttonConfig.questions.length - 1 ? TextInputStyle.Paragraph : TextInputStyle.Short)
                        .setRequired(true);
                    
                    modal.addComponents(new ActionRowBuilder().addComponents(questionInput));
                });
            } else {
                const detailsInput = new TextInputBuilder()
                    .setCustomId('details')
                    .setLabel('التفاصيل')
                    .setPlaceholder('اكتب تفاصيل طلبك هنا...')
                    .setStyle(TextInputStyle.Paragraph)
                    .setRequired(true);
                
                modal.addComponents(new ActionRowBuilder().addComponents(detailsInput));
            }
            
            await interaction.showModal(modal);
            return;
        }
        
        if (interaction.customId.startsWith('approve_')) {
            const ticketId = interaction.customId.replace('approve_', '');
            const ticket = ticketsDB.tickets.find(t => t.id === ticketId);
            
            if (!ticket) {
                return await interaction.reply({ content: 'لم يتم العثور على الطلب.', ephemeral: true });
            }
            
            ticket.status = 'approved';
            ticket.approvedBy = interaction.user.tag;
            saveTickets();
            
            try {
                const logsChannel = await client.channels.fetch(config.channels.ticketLogs);
                const logsEmbed = new EmbedBuilder()
                    .setTitle('✅ تم قبول الطلب')
                    .setDescription(`تم قبول طلب <@${ticket.userId}>`)
                    .addFields(
                        { name: '🏷️ نوع الطلب', value: ticket.type },
                        { name: '📝 التفاصيل', value: ticket.details },
                        { name: '👤 تمت الموافقة بواسطة', value: ticket.approvedBy }
                    )
                    .setColor('#28a745')
                    .setTimestamp()
                    .setFooter({ text: 'نظام الطلبات | تمت الموافقة' });
                
                await logsChannel.send({ embeds: [logsEmbed] });
                
                const responseChannel = await client.channels.fetch(config.channels.responseChannel);
                const user = await client.users.fetch(ticket.userId);
                
                const responseEmbed = new EmbedBuilder()
                    .setTitle('✅ تم قبول الطلب')
                    .setDescription(`مرحباً ${user.username}، تم قبول طلبك بنجاح!`)
                    .addFields(
                        { name: '🏷️ نوع الطلب', value: ticket.type, inline: true },
                        { name: '📅 تاريخ الطلب', value: new Date(ticket.createdAt).toLocaleDateString('ar-SA'), inline: true },
                        { name: '📝 التفاصيل', value: ticket.details }
                    )
                    .setColor('#28a745')
                    .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                    .setTimestamp()
                    .setFooter({ text: 'شكراً لتقديم طلبك! | نظام الطلبات' });
                
                await responseChannel.send({ content: `<@${ticket.userId}>`, embeds: [responseEmbed] });
                
                await user.send({ embeds: [responseEmbed] });
                
                await interaction.update({ content: 'تم قبول الطلب بنجاح.', components: [] });
            } catch (error) {
                console.error('خطأ في الموافقة على الطلب:', error);
                await interaction.reply({ content: 'حدث خطأ أثناء معالجة الطلب.', ephemeral: true });
            }
        } else if (interaction.customId.startsWith('reject_')) {
            const ticketId = interaction.customId.replace('reject_', '');
            
            const modal = new ModalBuilder()
                .setCustomId(`reject_modal_${ticketId}`)
                .setTitle('سبب رفض الطلب');
            
            const reasonInput = new TextInputBuilder()
                .setCustomId('reason')
                .setLabel('سبب الرفض')
                .setPlaceholder('اكتب سبب رفض الطلب هنا...')
                .setStyle(TextInputStyle.Paragraph)
                .setRequired(true);
            
            modal.addComponents(new ActionRowBuilder().addComponents(reasonInput));
            
            await interaction.showModal(modal);
        }
    } else if (interaction.isModalSubmit()) {
        if (interaction.customId.startsWith('modal_')) {
            const buttonId = interaction.customId.replace('modal_', '');
            const buttonConfig = config.buttons.find(btn => btn.id === buttonId);
            
            if (!buttonConfig) {
                return await interaction.reply({ content: 'حدث خطأ أثناء معالجة الطلب.', ephemeral: true });
            }
            
            const answers = [];
            let details = '';
            
            if (buttonConfig.questions && buttonConfig.questions.length > 0) {
                buttonConfig.questions.forEach((question, index) => {
                    const inputId = `question_${index}`;
                    const answer = interaction.fields.getTextInputValue(inputId);
                    answers.push({ question, answer });
                });
                
                details = answers.map(a => `**${a.question}**\n${a.answer}`).join('\n\n');
            } else {
                details = interaction.fields.getTextInputValue('details');
            }
            
            const ticket = {
                id: Date.now().toString(),
                userId: interaction.user.id,
                username: interaction.user.tag,
                type: buttonConfig.label,
                details: details,
                answers: answers.length > 0 ? answers : undefined,
                status: 'pending',
                createdAt: new Date().toISOString()
            };
            
            ticketsDB.tickets.push(ticket);
            saveTickets();
            
            try {
                const logsChannel = await client.channels.fetch(config.channels.ticketLogs);
                
                const embed = new EmbedBuilder()
                    .setTitle('🎫 طلب جديد')
                    .setDescription(`تم استلام طلب جديد من ${interaction.user.tag}`)
                    .addFields(
                        { name: '🏷️ نوع الطلب', value: buttonConfig.label, inline: true },
                        { name: '📅 تاريخ الطلب', value: new Date().toLocaleDateString('ar-SA'), inline: true },
                        { name: '📝 التفاصيل', value: details }
                    )
                    .setColor('#007bff')
                    .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
                    .setTimestamp()
                    .setFooter({ text: 'نظام الطلبات | طلب جديد' });
                
                const row = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId(`approve_${ticket.id}`)
                            .setLabel('موافقة')
                            .setStyle(ButtonStyle.Success)
                            .setEmoji('✅'),
                        new ButtonBuilder()
                            .setCustomId(`reject_${ticket.id}`)
                            .setLabel('رفض')
                            .setStyle(ButtonStyle.Danger)
                            .setEmoji('❌')
                    );
                
                await logsChannel.send({ embeds: [embed], components: [row] });
                
                await interaction.reply({ content: 'تم استلام طلبك بنجاح، سيتم مراجعته قريبًا.', ephemeral: true });
            } catch (error) {
                console.error('خطأ في معالجة الطلب:', error);
                await interaction.reply({ content: 'حدث خطأ أثناء معالجة طلبك، يرجى المحاولة مرة أخرى.', ephemeral: true });
            }
        } else if (interaction.customId.startsWith('reject_modal_')) {
            const ticketId = interaction.customId.replace('reject_modal_', '');
            const reason = interaction.fields.getTextInputValue('reason');
            const ticket = ticketsDB.tickets.find(t => t.id === ticketId);
            
            if (!ticket) {
                return await interaction.reply({ content: 'لم يتم العثور على الطلب.', ephemeral: true });
            }
            
            ticket.status = 'rejected';
            ticket.reason = reason;
            ticket.rejectedBy = interaction.user.tag;
            saveTickets();
            
            try {
                const logsChannel = await client.channels.fetch(config.channels.ticketLogs);
                const logsEmbed = new EmbedBuilder()
                    .setTitle('❌ تم رفض الطلب')
                    .setDescription(`تم رفض طلب <@${ticket.userId}>`)
                    .addFields(
                        { name: '🏷️ نوع الطلب', value: ticket.type },
                        { name: '📝 التفاصيل', value: ticket.details },
                        { name: '❓ سبب الرفض', value: reason },
                        { name: '👤 تم الرفض بواسطة', value: ticket.rejectedBy }
                    )
                    .setColor('#dc3545')
                    .setTimestamp()
                    .setFooter({ text: 'نظام الطلبات | تم الرفض' });
                
                await logsChannel.send({ embeds: [logsEmbed] });
                
                const responseChannel = await client.channels.fetch(config.channels.responseChannel);
                const user = await client.users.fetch(ticket.userId);
                
                const responseEmbed = new EmbedBuilder()
                    .setTitle('❌ تم رفض الطلب')
                    .setDescription(`مرحباً ${user.username}، نأسف لإبلاغك بأنه تم رفض طلبك.`)
                    .addFields(
                        { name: '🏷️ نوع الطلب', value: ticket.type, inline: true },
                        { name: '📅 تاريخ الطلب', value: new Date(ticket.createdAt).toLocaleDateString('ar-SA'), inline: true },
                        { name: '📝 التفاصيل', value: ticket.details },
                        { name: '❓ سبب الرفض', value: reason }
                    )
                    .setColor('#dc3545')
                    .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                    .setTimestamp()
                    .setFooter({ text: 'يمكنك تقديم طلب آخر في أي وقت | نظام الطلبات' });
                
                await responseChannel.send({ content: `<@${ticket.userId}>`, embeds: [responseEmbed] });
                
                await user.send({ embeds: [responseEmbed] });
                
                await interaction.reply({ content: 'تم رفض الطلب بنجاح.', ephemeral: true });
                
                const message = await interaction.channel.messages.fetch(interaction.message.id);
                await message.edit({ content: 'تم رفض الطلب.', components: [] });
            } catch (error) {
                console.error('خطأ في رفض الطلب:', error);
                await interaction.reply({ content: 'حدث خطأ أثناء معالجة الطلب.', ephemeral: true });
            }
        }
    }
});

client.login(config.token).then(() => {
    console.log('The login was successfully completed.✅');
    
    app.listen(config.port, () => {
        console.log(`The dashboard is started on the port ${config.port}`);
        console.log(`You can access the control panel via http://localhost:${config.port}`);
    });
}).catch(error => {
    console.error('Login error:', error);
});