document.addEventListener('DOMContentLoaded', function() {
    // التبديل بين عرض وإخفاء كلمة المرور مع تأثيرات أكثر نعومة
    const togglePasswordButtons = document.querySelectorAll('.toggle-password');
    togglePasswordButtons.forEach(button => {
        button.addEventListener('click', function() {
            const target = document.querySelector(this.getAttribute('data-target'));
            const type = target.getAttribute('type') === 'password' ? 'text' : 'password';
            
            // تأثير التحول بنعومة
            target.style.transition = 'opacity 0.3s ease';
            target.style.opacity = '0';
            
            setTimeout(() => {
                target.setAttribute('type', type);
                target.style.opacity = '1';
            }, 300);
            
            const icon = this.querySelector('i');
            icon.classList.toggle('bi-eye-slash');
            icon.classList.toggle('bi-eye');
        });
    });
    
    // معاينة لون البانل مع تأثير تحول
    const colorInput = document.getElementById('panelColor');
    if (colorInput) {
        const preview = document.querySelector('.color-preview');
        colorInput.addEventListener('input', function() {
            preview.style.transition = 'background-color 0.3s ease, transform 0.2s ease';
            preview.style.backgroundColor = this.value;
            preview.style.transform = 'scale(1.1)';
            
            setTimeout(() => {
                preview.style.transform = 'scale(1)';
            }, 200);
        });
    }
    
    // إخفاء التنبيهات بتأثير انزلاق وتلاشي
    const alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
    alerts.forEach(alert => {
        alert.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
        
        setTimeout(() => {
            alert.style.opacity = '0';
            alert.style.transform = 'translateY(-20px)';
            
            setTimeout(() => {
                alert.style.display = 'none';
            }, 500);
        }, 5000);
    });
    
    const cards = document.querySelectorAll('.card');
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px) scale(1.02)';
            this.style.boxShadow = '0 15px 40px rgba(45, 95, 109, 0.2)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
            this.style.boxShadow = '0 10px 30px rgba(45, 95, 109, 0.1)';
        });
    });
});