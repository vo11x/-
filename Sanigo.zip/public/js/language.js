const translations = {
    // Dashboard
    'dashboard': {
        'ar': 'لوحة التحكم',
        'en': 'Dashboard'
    },
    'tickets': {
        'ar': 'الطلبات',
        'en': 'Tickets'
    },
    'buttons': {
        'ar': 'أزرار البانل',
        'en': 'Panel Buttons'
    },
    'settings': {
        'ar': 'الإعدادات',
        'en': 'Settings'
    },
    'logout': {
        'ar': 'تسجيل الخروج',
        'en': 'Logout'
    },
    'total_tickets': {
        'ar': 'إجمالي الطلبات',
        'en': 'Total Tickets'
    },
    'pending_tickets': {
        'ar': 'طلبات قيد الانتظار',
        'en': 'Pending Tickets'
    },
    'processed_tickets': {
        'ar': 'طلبات تمت معالجتها',
        'en': 'Processed Tickets'
    },
    'latest_tickets': {
        'ar': 'اخر الطلبات',
        'en': 'Latest Tickets'
    },
    'view_all': {
        'ar': 'عرض الكل',
        'en': 'View All'
    },
    'send_panel': {
        'ar': 'إرسال البانل',
        'en': 'Send Panel'
    },
    'send_panel_info': {
        'ar': 'اضغط على الزر أدناه لإرسال بانل الطلبات إلى القناة المحددة في الإعدادات.',
        'en': 'Click the button below to send the request panel to the channel specified in the settings.'
    },

    // Tickets
    'manage_tickets': {
        'ar': 'إدارة الطلبات',
        'en': 'Manage Tickets'
    },
    'no_tickets': {
        'ar': 'لا توجد طلبات حتى الآن',
        'en': 'No tickets yet'
    },
    'number': {
        'ar': 'الرقم',
        'en': 'No.'
    },
    'type': {
        'ar': 'النوع',
        'en': 'Type'
    },
    'user': {
        'ar': 'المستخدم',
        'en': 'User'
    },
    'date': {
        'ar': 'التاريخ',
        'en': 'Date'
    },
    'status': {
        'ar': 'الحالة',
        'en': 'Status'
    },
    'actions': {
        'ar': 'الإجراءات',
        'en': 'Actions'
    },
    'view': {
        'ar': 'عرض',
        'en': 'View'
    },
    'approve': {
        'ar': 'موافقة',
        'en': 'Approve'
    },
    'reject': {
        'ar': 'رفض',
        'en': 'Reject'
    },
    'pending': {
        'ar': 'قيد الانتظار',
        'en': 'Pending'
    },
    'approved': {
        'ar': 'تمت الموافقة',
        'en': 'Approved'
    },
    'rejected': {
        'ar': 'مرفوض',
        'en': 'Rejected'
    },
    'approved_by': {
        'ar': 'تمت الموافقة بواسطة',
        'en': 'Approved By'
    },
    'rejected_by': {
        'ar': 'تم الرفض بواسطة',
        'en': 'Rejected By'
    },

    // Panel Buttons
    'panel_settings': {
        'ar': 'إعدادات البانل والأزرار',
        'en': 'Panel and Button Settings'
    },
    'panel_config': {
        'ar': 'إعدادات البانل',
        'en': 'Panel Settings'
    },
    'panel_title': {
        'ar': 'عنوان البانل',
        'en': 'Panel Title'
    },
    'panel_description': {
        'ar': 'وصف البانل',
        'en': 'Panel Description'
    },
    'panel_color': {
        'ar': 'لون البانل',
        'en': 'Panel Color'
    },
    'save_panel_settings': {
        'ar': 'حفظ اعدادات البانل',
        'en': 'Save Panel Settings'
    },
    'add_button': {
        'ar': 'إضافة زر جديد',
        'en': 'Add New Button'
    },
    'button_id': {
        'ar': 'معرف الزر',
        'en': 'Button ID'
    },
    'button_id_help': {
        'ar': 'معرف الزر مو اسمه ذا حط اي شي يمديك (بالإنجليزية، بدون مسافات)',
        'en': 'Button ID (English only, no spaces)'
    },
    'button_id_example': {
        'ar': 'مثال: request_role',
        'en': 'Example: request_role'
    },
    'button_name': {
        'ar': 'اسم الزر',
        'en': 'Button Name'
    },
    'button_style': {
        'ar': 'نمط الزر',
        'en': 'Button Style'
    },
    'blue': {
        'ar': '(ازرق)',
        'en': '(Blue)'
    },
    'gray': {
        'ar': '(رمادي)',
        'en': '(Gray)'
    },
    'green': {
        'ar': '(اخضر)',
        'en': '(Green)'
    },
    'red': {
        'ar': '(احمر)',
        'en': '(Red)'
    },
    'emoji': {
        'ar': 'إيموجي (اختياري)',
        'en': 'Emoji (Optional)'
    },
    'emoji_help': {
        'ar': 'يمديك تحط ايموجي مثل: 🏆, ✅, 🔔',
        'en': 'You can use emojis like: 🏆, ✅, 🔔'
    },
    'add': {
        'ar': 'اضافة الزر',
        'en': 'Add Button'
    },
    'current_buttons': {
        'ar': 'قائمة الأزرار الحالية',
        'en': 'Current Buttons List'
    },
    'no_buttons': {
        'ar': 'لا توجد أزرار حالياً',
        'en': 'No buttons yet'
    },
    'id': {
        'ar': 'المعرف',
        'en': 'ID'
    },
    'name': {
        'ar': 'الاسم',
        'en': 'Name'
    },
    'style': {
        'ar': 'النمط',
        'en': 'Style'
    },
    'preview': {
        'ar': 'معاينة',
        'en': 'Preview'
    },
    'edit': {
        'ar': 'تعديل',
        'en': 'Edit'
    },
    'delete': {
        'ar': 'حذف',
        'en': 'Delete'
    },
    'after_edit_buttons': {
        'ar': 'بعد تعديل الأزرار، اضغط على زر "إرسال البانل" في لوحة التحكم لتحديث البانل في القناة.',
        'en': 'After editing buttons, click the "Send Panel" button in the dashboard to update the panel in the channel.'
    },

    // Settings
    'system_settings': {
        'ar': 'إعدادات النظام',
        'en': 'System Settings'
    },
    'bot_channel_settings': {
        'ar': 'إعدادات البوت والقنوات',
        'en': 'Bot and Channel Settings'
    },
    'bot_settings': {
        'ar': 'إعدادات البوت',
        'en': 'Bot Settings'
    },
    'bot_token': {
        'ar': 'توكن البوت',
        'en': 'Bot Token'
    },
    'bot_id': {
        'ar': 'معرف البوت',
        'en': 'Bot ID'
    },
    'server_id': {
        'ar': 'معرف السيرفر',
        'en': 'Server ID'
    },
    'dashboard_port': {
        'ar': 'منفذ الداشبورد',
        'en': 'Dashboard Port'
    },
    'channel_settings': {
        'ar': 'إعدادات القنوات',
        'en': 'Channel Settings'
    },
    'panel_channel': {
        'ar': 'قناة عرض البانل',
        'en': 'Panel Display Channel'
    },
    'logs_channel': {
        'ar': 'قناة سجلات الطلبات',
        'en': 'Tickets Log Channel'
    },
    'response_channel': {
        'ar': 'قناة الردود',
        'en': 'Response Channel'
    },
    'user_settings': {
        'ar': 'إعدادات المستخدم',
        'en': 'User Settings'
    },
    'username': {
        'ar': 'اسم المستخدم',
        'en': 'Username'
    },
    'new_username': {
        'ar': 'اسم المستخدم الجديد',
        'en': 'New Username'
    },
    'password': {
        'ar': 'كلمة المرور',
        'en': 'Password'
    },
    'new_password': {
        'ar': 'كلمة المرور الجديدة',
        'en': 'New Password'
    },
    'save_settings': {
        'ar': 'حفظ الإعدادات',
        'en': 'Save Settings'
    },

    // Modals
    'ticket_details': {
        'ar': 'تفاصيل الطلب',
        'en': 'Ticket Details'
    },
    'close': {
        'ar': 'إغلاق',
        'en': 'Close'
    },
    'details': {
        'ar': 'التفاصيل',
        'en': 'Details'
    },
    'rejection_reason': {
        'ar': 'سبب الرفض',
        'en': 'Rejection Reason'
    },
    'ticket_details_info': {
        'ar': 'تفاصيل الطلب:',
        'en': 'Ticket Details:'
    },
    'confirm_approval': {
        'ar': 'تأكيد الموافقة',
        'en': 'Confirm Approval'
    },
    'approval_confirm_question': {
        'ar': 'هل أنت متأكد من الموافقة على هذا الطلب؟',
        'en': 'Are you sure you want to approve this ticket?'
    },
    'approval_confirm_info': {
        'ar': 'سيتم إرسال إشعار للمستخدم بالموافقة على طلبه.',
        'en': 'A notification will be sent to the user approving their request.'
    },
    'cancel': {
        'ar': 'إلغاء',
        'en': 'Cancel'
    },
    'confirm_approval_button': {
        'ar': 'تأكيد الموافقة',
        'en': 'Confirm Approval'
    },
    'reject_ticket': {
        'ar': 'رفض الطلب',
        'en': 'Reject Ticket'
    },
    'rejection_reason_label': {
        'ar': 'سبب الرفض:',
        'en': 'Rejection Reason:'
    },
    'rejection_warning': {
        'ar': 'سيتم إرسال إشعار للمستخدم بسبب رفض طلبه.',
        'en': 'A notification will be sent to the user with the reason for rejecting their request.'
    },
    'confirm_rejection': {
        'ar': 'تأكيد الرفض',
        'en': 'Confirm Rejection'
    },
    'edit_button': {
        'ar': 'تعديل الزر',
        'en': 'Edit Button'
    },
    'save_changes': {
        'ar': 'حفظ التغييرات',
        'en': 'Save Changes'
    },
    'delete_button': {
        'ar': 'حذف الزر',
        'en': 'Delete Button'
    },
    'delete_button_confirm': {
        'ar': 'هل أنت متأكد من حذف الزر',
        'en': 'Are you sure you want to delete the button'
    },
    'delete_warning': {
        'ar': 'تحذير: لا يمكن التراجع عن هذه العملية!',
        'en': 'Warning: This action cannot be undone!'
    },
    'confirm_delete': {
        'ar': 'تأكيد الحذف',
        'en': 'Confirm Delete'
    },

    // Login page
    'login': {
        'ar': 'تسجيل الدخول',
        'en': 'Login'
    },
    'login_panel': {
        'ar': 'لوحة تحكم نظام الطلبات',
        'en': 'Ticket System Control Panel'
    },
    'login_button': {
        'ar': 'تسجيل الدخول',
        'en': 'Login'
    },

    // Add theme translations
    'dark_mode': {
        'ar': 'الوضع الداكن',
        'en': 'Dark Mode'
    },
    'light_mode': {
        'ar': 'الوضع الفاتح',
        'en': 'Light Mode'
    }
};

let currentLanguage = localStorage.getItem('dashboard_language') || 'ar';
let currentTheme = localStorage.getItem('dashboard_theme') || 'light';

function toggleLanguage() {
    currentLanguage = currentLanguage === 'ar' ? 'en' : 'ar';
    localStorage.setItem('dashboard_language', currentLanguage);
    applyLanguage();
}

function toggleTheme() {
    currentTheme = currentTheme === 'light' ? 'dark' : 'light';
    localStorage.setItem('dashboard_theme', currentTheme);
    applyTheme();
}

function getTranslation(key) {
    if (translations[key] && translations[key][currentLanguage]) {
        return translations[key][currentLanguage];
    }
    return key;
}

function applyLanguage() {
    document.documentElement.dir = currentLanguage === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = currentLanguage;
    
    const langToggle = document.getElementById('language-toggle');
    if (langToggle) {
        langToggle.textContent = currentLanguage === 'ar' ? 'English' : 'العربية';
    }
    
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) {
        themeToggle.textContent = currentTheme === 'light' 
            ? getTranslation('dark_mode') 
            : getTranslation('light_mode');
    }
    
    const elements = document.querySelectorAll('[data-lang]');
    elements.forEach(element => {
        const key = element.getAttribute('data-lang');
        element.textContent = getTranslation(key);
    });
    
    const inputElements = document.querySelectorAll('[data-lang-placeholder]');
    inputElements.forEach(element => {
        const key = element.getAttribute('data-lang-placeholder');
        element.placeholder = getTranslation(key);
    });
    
    const buttons = document.querySelectorAll('button[data-lang-btn]');
    buttons.forEach(button => {
        const key = button.getAttribute('data-lang-btn');
        const icon = button.querySelector('i') ? button.querySelector('i').outerHTML + ' ' : '';
        button.innerHTML = icon + getTranslation(key);
    });
}

function applyTheme() {
    document.documentElement.setAttribute('data-theme', currentTheme);
    
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) {
        themeToggle.textContent = currentTheme === 'light' 
            ? getTranslation('dark_mode') 
            : getTranslation('light_mode');
        
        themeToggle.innerHTML = `<i class="bi bi-${currentTheme === 'light' ? 'moon' : 'sun'}"></i> ` + 
            (currentTheme === 'light' ? getTranslation('dark_mode') : getTranslation('light_mode'));
    }
}

function addLanguageToggle() {
    if (!document.getElementById('language-toggle')) {
        const navbar = document.querySelector('.sidebar');
        if (navbar) {
            const toggleButton = document.createElement('button');
            toggleButton.id = 'language-toggle';
            toggleButton.className = 'btn btn-outline-light language-btn';
            toggleButton.textContent = currentLanguage === 'ar' ? 'English' : 'العربية';
            toggleButton.onclick = toggleLanguage;
            toggleButton.style.position = 'absolute';
            toggleButton.style.bottom = '20px';
            toggleButton.style.left = '20px';
            navbar.appendChild(toggleButton);
            
            // Add theme toggle button
            const themeButton = document.createElement('button');
            themeButton.id = 'theme-toggle';
            themeButton.className = 'btn btn-outline-light theme-toggle';
            themeButton.innerHTML = `<i class="bi bi-${currentTheme === 'light' ? 'moon' : 'sun'}"></i> ` + 
                (currentTheme === 'light' ? getTranslation('dark_mode') : getTranslation('light_mode'));
            themeButton.onclick = toggleTheme;
            navbar.appendChild(themeButton);
        }
    }
    
    addLanguageAttributes();
}

function addLanguageAttributes() {
    const elementMap = {
        '.sidebar .logo': 'dashboard',
        '.sidebar .nav-link[href="#dashboard"] i + span': 'dashboard',
        '.sidebar .nav-link[href="#tickets"] i + span': 'tickets',
        '.sidebar .nav-link[href="#buttons"] i + span': 'buttons',
        '.sidebar .nav-link[href="#settings"] i + span': 'settings',
        '.sidebar .nav-link[href="/logout"] i + span': 'logout',
    };
    
    for (const selector in elementMap) {
        const elements = document.querySelectorAll(selector);
        elements.forEach(element => {
            if (!element.hasAttribute('data-lang')) {
                element.setAttribute('data-lang', elementMap[selector]);
            }
        });
    }
}

document.addEventListener('DOMContentLoaded', function() {
    addLanguageToggle();
    
    applyLanguage();
    applyTheme();
});

function addLanguageStyles() {
    const style = document.createElement('style');
    style.textContent = `
        /* RTL specific styles */
        html[dir="rtl"] .sidebar {
            right: 0;
            left: auto;
        }
        
        html[dir="rtl"] .content {
            margin-right: 280px;
            margin-left: 0;
        }
        
        html[dir="rtl"] .sidebar .nav-link i {
            margin-left: 15px;
            margin-right: 0;
        }
        
        html[dir="rtl"] .form-floating > label {
            right: 0;
            left: auto;
            padding-right: 15px;
            padding-left: 0;
        }
        
        /* LTR specific styles */
        html[dir="ltr"] .sidebar {
            left: 0;
            right: auto;
        }
        
        html[dir="ltr"] .content {
            margin-left: 280px;
            margin-right: 0;
        }
        
        html[dir="ltr"] .sidebar .nav-link i {
            margin-right: 15px;
            margin-left: 0;
        }
        
        html[dir="ltr"] .form-floating > label {
            left: 0;
            right: auto;
            padding-left: 15px;
            padding-right: 0;
        }
        
        /* Language button */
        .language-btn {
            position: absolute;
            bottom: 20px;
            left: 20px;
            z-index: 1010;
            border-radius: 10px;
            padding: 8px 15px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .language-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(255, 255, 255, 0.2);
        }
        
        @media (max-width: 768px) {
            html[dir="rtl"] .content {
                margin-right: 0;
            }
            
            html[dir="ltr"] .content {
                margin-left: 0;
            }
            
            .language-btn {
                position: fixed;
                bottom: 20px;
                right: 20px;
                z-index: 1030;
            }
        }
    `;
    document.head.appendChild(style);
}

addLanguageStyles();