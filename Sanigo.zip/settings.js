const fs = require('fs');

const defaultConfig = {
    token: "توكن_البوت_هنا",
    clientId: "ايدي_البوت_هنا",
    guildId: "ايدي_السيرفر_هنا",
    port: 3000,
    admin: {
        username: "admin",
        password: "admin123"
    },
    channels: {
        ticketPanel: "", 
        ticketLogs: "", 
        responseChannel: "" 
    },
    buttons: [
        {
            id: "request_role",
            label: "طلب رتبة",
            style: "PRIMARY",
            emoji: "🏆",
            questions: [
                "ما هو سبب طلبك للرتبة؟"
            ]
        },
        {
            id: "change_name",
            label: "تغيير اسم",
            style: "SECONDARY",
            emoji: "✏️",
            questions: [
                "ما هو الاسم الجديد المطلوب؟"
            ]
        }
    ],
    panelTitle: "نظام الطلبات",
    panelDescription: "اضغط على الزر المناسب لتقديم طلبك",
    panelColor: "#007bff",
    panelImage: ""
};

if (!fs.existsSync('./config.json')) {
    fs.writeFileSync('./config.json', JSON.stringify(defaultConfig, null, 4));
}

const config = JSON.parse(fs.readFileSync('./config.json', 'utf8'));

if (!config.buttons) {
    config.buttons = defaultConfig.buttons;
} else {
    config.buttons.forEach(button => {
        if (!button.questions) {
            button.questions = ["ما هي تفاصيل طلبك؟"];
        }
    });
}

if (!config.panelTitle) {
    config.panelTitle = defaultConfig.panelTitle;
}

if (!config.panelDescription) {
    config.panelDescription = defaultConfig.panelDescription;
}

if (!config.panelColor) {
    config.panelColor = defaultConfig.panelColor;
}

if (!config.panelImage) {
    config.panelImage = defaultConfig.panelImage;
}

const finalConfig = {...defaultConfig, ...config};

function saveConfig() {
    fs.writeFileSync('./config.json', JSON.stringify(finalConfig, null, 4));
}

module.exports = {
    config: finalConfig,
    saveConfig
};